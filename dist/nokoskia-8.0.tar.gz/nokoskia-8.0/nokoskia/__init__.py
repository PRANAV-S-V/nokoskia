# __init__.py

# Comment out the import statement
# from .nokoskia import knock

def knock():
    # Import the knock function when needed
    from .nokoskia import knock
    knock()

# You can also define other functions or variables here if needed

